package gui;


import functionallogic.Patient;
import functionallogic.User;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

import static functionallogic.User.us;

public class UserView extends Stage {

    private Controller co;

    public UserView(Controller co, Stage primaryStage) {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.co = co;
    }


    public void showView() {
        Label l1 = new Label("Name:");
        Label l2 = new Label("Passwort:");


        TextField t1;
        TextField t2;


        t1 = new TextField("");
        t2 = new TextField("");


        Button ok = new Button("OK");
        Button abbr = new Button("Cancel");

        ok.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if (t1.getText().equals("Arzt") && t2.getText().equals("Arzt")) {
                        us.setRechte(1);

                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Anmeldung");
                        alert.setHeaderText(null);
                        alert.setContentText("Sie wurden erfolgreich angemeldet");
                        alert.showAndWait();

                        close();
                    } else if (t1.getText().equals("Heilberufler") && t2.getText().equals("Heilberufler")) {
                        us.setRechte(2);

                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Anmeldung");
                        alert.setHeaderText(null);
                        alert.setContentText("Sie wurden erfolgreich angemeldet");
                        alert.showAndWait();

                        close();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Fehler bei der Anmeldung");
                        alert.setHeaderText("Die Anmeldedaten stimmen nicht");
                        alert.setContentText("Bitte geben Sie die Anmeldedaten erneut ein");

                        alert.showAndWait();
                    }
                } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        HBox hb = new HBox();
        hb.getChildren().addAll(ok, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addColumn(0, l1, l2);
        gp.addColumn(1, t1, t2);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t1, Priority.ALWAYS);
        GridPane.setHalignment(l1, HPos.RIGHT);
        GridPane.setHalignment(l2, HPos.RIGHT);

        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);

        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Login");

        this.show();

    }
}
