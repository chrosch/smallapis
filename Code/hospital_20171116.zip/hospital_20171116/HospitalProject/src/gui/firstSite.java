package gui;

import functionallogic.Diagnose;
import functionallogic.Patient;
import functionallogic.User;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import static functionallogic.User.us;

public class firstSite extends Application{

	@Override
	public void start(Stage primaryStage) {
		Controller co = new Controller();
        ListView lv = new ListView();
            
        MenuBar mb = new MenuBar();
        Menu datei = new Menu("Object");

        MenuItem mi1 = new MenuItem("Load Patient List");
        MenuItem mi2 = new MenuItem("Load Diagnostic of Patient");
        MenuItem mi3 = new MenuItem("Patient Search");
        MenuItem mi4 = new MenuItem("Beenden");


        mi1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle (ActionEvent event){
                if((us.getRechte() == 1) | (us.getRechte() == 2)) {
                    co.patientListLoad();
                }
            }
        });

        mi2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if ((us.getRechte() == 1) | (us.getRechte() == 2)) {
                    PatientDiagnosticListView pdlv = new PatientDiagnosticListView(new Patient(), co, primaryStage);
                    pdlv.showView();
                }
            }
        });
//
        mi3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if((us.getRechte() == 1) | (us.getRechte() == 2)) {
                    SinglePatientView spv = new SinglePatientView(new Patient(), co, primaryStage);
                    spv.showView();
                }
            }
        });

        mi4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });


        datei.getItems().addAll(mi1, mi2, mi3, mi4);

        Menu medium = new Menu("Patient");

        MenuItem mi5 = new MenuItem("Add Patient");
        MenuItem mi6 = new MenuItem("Add Diagnose");


        mi5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if((us.getRechte() == 1) | (us.getRechte() == 2)) {
                    PatientAddView pav = new PatientAddView(new Patient(), co, primaryStage);
                    pav.showView();
                }
            }
        });

        mi6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if(us.getRechte() == 1) {
                    DiagnoseAddView dav = new DiagnoseAddView(new Diagnose(), co, primaryStage);
                    dav.showView();
                }
            }
        });



        medium.getItems().addAll(mi5, mi6);

        Menu login = new Menu("Anmelden");

        MenuItem mi7 = new MenuItem("Anmelden");
        mi7.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                UserView uv = new UserView(co,primaryStage);
                uv.showView();
            }
        });
        
        login.getItems().addAll(mi7);


        mb.getMenus().addAll(datei, medium, login);

        BorderPane bp = new BorderPane();

        //lv.setItems(co.getList());
        lv.setItems(co.getList());
        bp.setTop(mb);
        bp.setCenter(lv);

        Scene scene = new Scene(bp, 300.0, 200.0);
        primaryStage.setTitle("Patient administration");
        primaryStage.setScene(scene);
        primaryStage.show();

		
	}
	
	public static void main(String[] args) {
	    launch(args);
	}

}
