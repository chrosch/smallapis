package functionallogic;

public class Patient {
	
	private String familyName;
	private String givenName;
	private String patientID;
	private String streetName;
	private String dwellingNumber;
	
	
	public Patient() {
		
	}
	
	

	public String getPatientID() {
		return patientID;
	}



	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}



	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	

	public String getStreetName() {
		return streetName;
	}



	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}



	public String getDwellingNumber() {
		return dwellingNumber;
	}



	public void setDwellingNumber(String dwellingNumber) {
		this.dwellingNumber = dwellingNumber;
	}



	@Override
	public String toString() {
		return  familyName + " " + givenName + " " + patientID;
	}
	
	

}
