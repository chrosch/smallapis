package functionallogic;

public class User {

    public static User us = new User(0);
    private int rechte;

    public User(int rechte){
        this.rechte = rechte;
    }

    public void setRechte(int rechte){
        this.rechte = rechte;
    }

    public int getRechte(){
        return rechte;
    }




}
