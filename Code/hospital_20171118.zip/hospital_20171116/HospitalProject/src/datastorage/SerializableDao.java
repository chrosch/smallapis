package datastorage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import functionallogic.Diagnose;
import functionallogic.Patient;

public class SerializableDao {
	
	
	private static final String JDCB_DRIVER = "org.mariadb.jdbc.Driver";
	private static final Connection con = createDatabaseConnection("localhost", "hospital", "root", "");
	private static final List<Patient> patientList = new LinkedList<>();
	private static final List<Diagnose> diagnoseList = new LinkedList<>();
	
	private static Connection createDatabaseConnection(String host, String database, String user, String pass) {
		Connection connection = null;

		try {
			Class.forName(JDCB_DRIVER);
			connection = DriverManager.getConnection("jdbc:mariadb://"+host+"/"+database, user, pass);
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return connection;
	}
	
	public List<Patient> patientListReader(){
		
		String query2 = "Select patientID, givenName, familyName, streetName, dwellingNumber From patient;";
		
		try(Statement stmt = con.createStatement();
				ResultSet resultSet = stmt.executeQuery(query2)){
			int counter = 0;
			
			while(resultSet.next()) {
				Patient patient = new Patient();
				counter++;
				System.out.println(counter);
				patient.setPatientID(resultSet.getString("patientID"));
				patient.setFamilyName(resultSet.getString("familyName"));
				patient.setGivenName(resultSet.getString("givenName"));
				patient.setStreetName(resultSet.getString("streetName"));
				patient.setDwellingNumber(resultSet.getString("dwellingNumber"));

				patientList.add(patient);
			}
		}catch(SQLException ex){
			ex.printStackTrace();
		}
		return patientList;
	}
	
	public Patient patientReader(String patientID) {
		String query2 = "Select patientID, givenName, familyName, streetName, dwellingNumber From patient;";
		Patient patient = new Patient();
		try (Statement stmt = con.createStatement(); ResultSet resultSet = stmt.executeQuery(query2)) {
			int counter = 0;
			while (resultSet.next()) {
				if(resultSet.getString("patientID").equals(patientID)) {
					counter++;
					System.out.println(counter);
					patient.setPatientID(resultSet.getString("patientID"));
					patient.setFamilyName(resultSet.getString("familyName"));
					patient.setGivenName(resultSet.getString("givenName"));
					patient.setStreetName(resultSet.getString("streetName"));
					patient.setDwellingNumber(resultSet.getString("dwellingNumber"));
//					return patient;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return patient;
	}
	
	public Diagnose diagnoseReader(String visitNumber) {
		String query2 = "Select patientID, visitNumber, result, adID, adPrefix, adGivenName, adFamilyName From diagnose;";
		Diagnose diagnose = new Diagnose();
		try (Statement stmt = con.createStatement(); ResultSet resultSet = stmt.executeQuery(query2)) {
			int counter = 0;
			while (resultSet.getString("visitNumber")== visitNumber) {
				counter++;
				System.out.println(counter);
				diagnose.setPatientID("patientID");
				diagnose.setVisitNumber("visitNumber");
				diagnose.setResult("result");
				diagnose.setAdID("adID");
				diagnose.setAdPrefix("adPrefix");
				diagnose.setAdFamilyName("adFamilyName");
				diagnose.setAdGivenName("adGivenName");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return diagnose;
	}

	public List<Diagnose> diagnoseListReader(String patientID) {
		String query2 = "Select patientID, visitNumber, result, adID, adPrefix, adGivenName, adFamilyName From diagnose;";
		
		try (Statement stmt = con.createStatement(); ResultSet resultSet = stmt.executeQuery(query2)) {
			int counter = 0;
			while (resultSet.next()) {
				if(resultSet.getString("patientID").equals(patientID)){
					Diagnose diagnose = new Diagnose();
					counter++;
					System.out.println(counter);
					diagnose.setPatientID("patientID");
					diagnose.setVisitNumber("visitNumber");
					diagnose.setResult("result");
					diagnose.setAdID("adID");
					diagnose.setAdPrefix("adPrefix");
					diagnose.setAdFamilyName("adFamilyName");
					diagnose.setAdGivenName("adGivenName");
					diagnoseList.add(diagnose);
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return diagnoseList;
	}
	
	public void patientWriter(Patient patient)  {//List<Helper2> liste2
		String insertSQL = "INSERT INTO patient (patientID, givenName, familyName, streetName, dwellingNumber) VALUES(?, ?, ?, ?, ?)";
		try(Statement stmt = con.createStatement();
				PreparedStatement preparedStatement = con.prepareStatement(insertSQL)){
				preparedStatement.setString(1, patient.getPatientID());
				preparedStatement.setString(2, patient.getGivenName());
				preparedStatement.setString(3, patient.getFamilyName());
				preparedStatement.setString(4, "");
				preparedStatement.setString(5, "");
				preparedStatement.executeUpdate();
		}catch(SQLException ex){
			ex.printStackTrace();
		}
	}
	
	public void diagnoseWriter(Diagnose diagnose)  {//List<Helper2> liste2
		String insertSQL = "INSERT INTO  diagnose(patientID, visitNumber, result, adID, adPrefix, adGivenName, adFamilyName) VALUES(?, ?, ?, ?, ?, ?, ?)";
		try(
				Statement stmt = con.createStatement();
				PreparedStatement preparedStatement = con.prepareStatement(insertSQL)){
				preparedStatement.setString(1, diagnose.getPatientID());
				preparedStatement.setString(2, diagnose.getVisitNumber());
				preparedStatement.setString(3, diagnose.getResult());
				preparedStatement.setString(4, diagnose.getAdID());
				preparedStatement.setString(5, diagnose.getAdPrefix());
				preparedStatement.setString(6, diagnose.getAdGivenName());
				preparedStatement.setString(7, diagnose.getAdFamilyName());
				preparedStatement.executeUpdate();
		}catch(SQLException ex){
			ex.printStackTrace();
		}
	}
}
