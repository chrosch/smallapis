package functionallogic;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import gui.Controller;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.LinkedList;

public class FhirMethods {

    public ObservableList<Patient> loadList(String url, ObservableList<Patient> patlist) {

        patlist.clear();

        for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

            JsonElement root = new JsonParser().parse(url);
            JsonElement entry = root.getAsJsonObject().get("entry");
            JsonElement current_entry = entry.getAsJsonArray().get(i);
            JsonElement resource = current_entry.getAsJsonObject().get("resource");
            JsonElement name = resource.getAsJsonObject().get("name");
            JsonArray nameList = name.getAsJsonArray();
            JsonElement nameListEntry = nameList.get(0);
            String famname = nameListEntry.getAsJsonObject().get("family").getAsString();

            String[] nameListArray = new String[nameList.size()];
            for(int a = 0; a < nameListArray.length; a++){
                nameListEntry = nameList.get(a);
                nameListArray[a] = nameListEntry.getAsJsonObject().get("given").getAsString();
            }

            JsonElement id = resource.getAsJsonObject().get("id");
            String fhirid = id.getAsString();

            Patient pat = new Patient();
            pat.setFamilyName(famname);
            pat.setGivenNameArray(nameListArray);
            pat.setFhirid(fhirid);

            patlist.add(pat);
        }

        return patlist;
    }

    public ObservableList<Diagnose> loadDiagList(String url, ObservableList<Diagnose> diaglist) {

        diaglist.clear();

        for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

            JsonElement root = new JsonParser().parse(url);
            JsonElement entry = root.getAsJsonObject().get("entry");
            JsonElement current_entry = entry.getAsJsonArray().get(i);
            JsonElement resource = current_entry.getAsJsonObject().get("resource");
            JsonElement id = resource.getAsJsonObject().get("id");
            String idstring = id.getAsString();

            JsonElement code = resource.getAsJsonObject().get("code");
            String text = code.getAsJsonObject().get("text").getAsString();

            JsonElement subject = resource.getAsJsonObject().get("subject");
            JsonElement reference = subject.getAsJsonObject().get("reference");
            String withPatient = reference.getAsString();
            String Patientid = withPatient.substring(8);

            Diagnose diag = new Diagnose();
            diag.setAdID(idstring);
            diag.setPatientID(Patientid);
            diag.setResult(text);

            diaglist.add(diag);
        }

        return diaglist;
    }

    public ObservableList<Diagnose> loadDiagList2(String url, ObservableList<Diagnose> diaglist, ObservableList list) {

        list.clear();
        diaglist.clear();

        try {
            for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

                JsonElement root = new JsonParser().parse(url);
                JsonElement entry = root.getAsJsonObject().get("entry");
                JsonElement current_entry = entry.getAsJsonArray().get(i);
                JsonElement resource = current_entry.getAsJsonObject().get("resource");
                JsonElement id = resource.getAsJsonObject().get("id");
                String idstring = id.getAsString();

                JsonElement code = resource.getAsJsonObject().get("code");
                String text = code.getAsJsonObject().get("text").getAsString();

                JsonElement subject = resource.getAsJsonObject().get("subject");
                JsonElement reference = subject.getAsJsonObject().get("reference");
                String withPatient = reference.getAsString();
                String Patientid = withPatient.substring(8);

                JsonElement meta = resource.getAsJsonObject().get("meta");
                JsonElement versionID = meta.getAsJsonObject().get("versionId");
                String visitNumber = versionID.getAsString();

                Diagnose diag = new Diagnose();
                diag.setVisitNumber(visitNumber);
                diag.setAdID(idstring);
                diag.setPatientID(Patientid);
                diag.setResult(text);

                diaglist.add(diag);
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Keine Diagnosen gefunden");
            alert.setHeaderText(null);
            alert.setContentText("Es wurden keine Diagnosen gefunden");
            alert.showAndWait();
        }
        return diaglist;
    }

    public ObservableList<Patient> loadList2(String url, String text1, String text2, ObservableList<Patient> patlist, ObservableList<String> list) {

        patlist = this.loadList(url, patlist);
        LinkedList<Integer> merker = new LinkedList<Integer>();

        if(text1.equals("") | text2.equals("")){
            if(text1.equals("")){
                for(int i = 0; i<patlist.size(); i++) {
                    if (patlist.get(i).getFamilyName().startsWith(text2)) {
                    }else{
                        merker.add(i);
                    }
                }

                for(int a = merker.size() -1; a >= 0; a--){
                    patlist.remove((int) merker.get(a));
                    merker.remove(a);
                }

            }else{
                for(int i = 0; i<patlist.size(); i++) {
                    if (patlist.get(i).getGivenNameArray()[0].startsWith(text1)) {
                    }else{
                        merker.add(i);
                    }
                }

                for(int a = merker.size() -1; a >= 0; a--){
                    patlist.remove((int) merker.get(a));
                    merker.remove(a);
                }

            }
        }else{
            for(int i = 0; i<patlist.size(); i++) {
                if (patlist.get(i).getFamilyName().startsWith(text2) && (patlist.get(i).getGivenNameArray()[0].startsWith(text1))) {
                }else{
                    merker.add(i);
                }
            }

            for(int a = merker.size() -1; a >= 0; a--){
                patlist.remove((int) merker.get(a));
                merker.remove(a);
            }

        }

        return patlist;
    }

    public ObservableList<Diagnose> loadList2Diag(String url, String text, ObservableList<Diagnose> diaglist) {

        loadDiagList(url, diaglist);
        LinkedList<Integer> merker = new LinkedList<Integer>();

        for(int i = 0; i<diaglist.size(); i++) {
            if (diaglist.get(i).getResult().startsWith(text)) {
            }else{
                merker.add(i);
            }
        }

        for(int a = merker.size() -1; a >= 0; a--){
            diaglist.remove((int) merker.get(a));
            merker.remove(a);
        }

        return diaglist;
    }

    public ObservableList<String> loadStringList(ObservableList<Patient> patlist, ObservableList<String> list){
        list.clear();
        for(int i = 0; i < patlist.size(); i++){
            list.add(patlist.get(i).toString2());
        }
        return list;
    }

    public ObservableList<String> loadStringListDiag(ObservableList<Diagnose> diaglist, ObservableList<String> list){
        list.clear();
        for(int i = 0; i < diaglist.size(); i++){
            list.add(diaglist.get(i).toString2());
        }

        return list;
    }

    public String readUrl(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);

            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }

    public void createPatient(Patient pat, Controller co) {
        if (pat.getPatientID() == null) {
            try {
                Patient patient = pat;
                patient.setPatientID(co.getNewPatientID());
                patient.setGivenName(patient.getGivenNameArray()[0]);
                patient.setFamilyName(patient.getFamilyName());
                co.patientAdd(patient);
            } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
            }
        }
    }

    public void createDiagnose(Diagnose diagnose, Patient pat, Controller co){
        diagnose.setAdGivenName(pat.getGivenName());
        diagnose.setAdFamilyName(pat.getFamilyName());
        diagnose.setAdPrefix(null);

        co.diagnoseAdd(diagnose);
    }

}

