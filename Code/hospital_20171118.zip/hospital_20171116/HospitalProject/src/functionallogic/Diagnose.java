package functionallogic;

public class Diagnose {
	//ad = attanding Doctor
	private String patientID;
	private String visitNumber;
	private String adID;
	private String adPrefix;
	private String adGivenName;
	private String adFamilyName;
	private String result;
	
	public Diagnose() {
		
	}

	public String getPatientID() {
		return patientID;
	}

	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	public String getVisitNumber() {
		return visitNumber;
	}

	public void setVisitNumber(String visitNumber) {
		this.visitNumber = visitNumber;
	}

	public String getAdID() {
		return adID;
	}

	public void setAdID(String adID) {
		this.adID = adID;
	}

	public String getAdPrefix() {
		return adPrefix;
	}

	public void setAdPrefix(String adPrefix) {
		this.adPrefix = adPrefix;
	}

	public String getAdGivenName() {
		return adGivenName;
	}

	public void setAdGivenName(String adGivenName) {
		this.adGivenName = adGivenName;
	}

	public String getAdFamilyName() {
		return adFamilyName;
	}

	public void setAdFamilyName(String adFamilyName) {
		this.adFamilyName = adFamilyName;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "Diagnose [patientID=" + patientID + ", visitNumber=" + visitNumber + ", adID=" + adID + ", adPrefix="
				+ adPrefix + ", adGivenName=" + adGivenName + ", adFamilyName=" + adFamilyName + ", result=" + result
				+ "]";
	}

	public String toString2(){
		return result + "  patientID=" + patientID + "  adID=" + adID;
	}
	
	
	

}
