package functionallogic;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import datastorage.SerializableDao;

public class Comparator {
	List<Patient> patientList = new LinkedList<>();
	List<Diagnose> diagnoseList = new LinkedList<>();
	Patient patient = new Patient();
	private SerializableDao sDao = new SerializableDao();

	public void patientWrite(Patient patient) {
		sDao.patientWriter(patient);
	}

	public void patientAddToList(Patient patient) {
		patientList.add(patient);
	}
	
	public void diagnoseAddToList(Diagnose diagnose) {
		diagnoseList.add(diagnose);
	}
	
	public void patientListRead() {
		patientList = sDao.patientListReader();
		
	}
	
	public String generatePatientID() {
		String id = Long.toString(System.currentTimeMillis());
		return id;
	}

	public String generateVisitNumber() {
		String number = Long.toString(System.currentTimeMillis());
		return number;
	}

	
	public void patientRead(String patientID) {
		patient = sDao.patientReader(patientID);
	}
	
	public void diagnoseWrite(Diagnose diagnose) {
		sDao.diagnoseWriter(diagnose);
	}
	
	public void diagnoseListRead(String patientID) {
		sDao.diagnoseListReader(patientID);
	}
	
	public void diagnoseRead(String visitNumber) {
		sDao.diagnoseReader(visitNumber);
	}
	
	public Iterator<Patient> iterator(){
		Iterator<Patient> it = patientList.iterator();
		return it;
	}
}
