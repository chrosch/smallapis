package gui;

import java.util.Iterator;

import functionallogic.Comparator;
import functionallogic.Diagnose;
import functionallogic.Patient;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Controller {
	private Comparator com;
    private ObservableList<String> ol = FXCollections.observableArrayList();
    
    public Controller(){
        com = new Comparator();
    }
    
    public void patientListLoad(){
        com.patientListRead();
        ol.clear();
        Iterator<?> it = com.iterator();
        while(it.hasNext()){
            ol.add(it.next().toString());
        }
        /*
        for(Medium m: mv.iterator().hasNext()){
            ol.add(m.toString());
        }
         */
    }
    
    public String getNewPatientID() {
    	return com.generatePatientID();
    }
    
    public void patientAdd(Patient patient) {
    	com.patientWrite(patient);
    	com.patientAddToList(patient);
    	ol.add(patient.toString());
    }
    
    public void diagnoseAdd(Diagnose diagnose) {
    	com.diagnoseWrite(diagnose);
    	com.diagnoseAddToList(diagnose);
    	ol.add(diagnose.toString());
    }
    
//    public void medienInDatei(Stage ob){
//        String dateiname = InputView.create(ob, "Eingabe", "Dateiname", null).showView();
//        mv.medienInDateiSchreiben(dateiname);
//    }
    
    public ObservableList<String> getList(){
        return ol;
    }

}
