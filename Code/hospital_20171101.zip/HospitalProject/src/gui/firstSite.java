package gui;

import functionallogic.Diagnose;
import functionallogic.Patient;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class firstSite extends Application{

	@Override
	public void start(Stage primaryStage) {
		Controller co = new Controller();
        ListView lv = new ListView();
            
        MenuBar mb = new MenuBar();
        Menu datei = new Menu("Object");

        MenuItem mi1 = new MenuItem("Load Patient List");

        mi1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
            	co.patientListLoad();
            }
        });

//        MenuItem mi2 = new MenuItem("Speichern");
//        mi2.setOnAction(new EventHandler<ActionEvent>() {
//            @Override
//            public void handle(ActionEvent event) {
//                co.medienSpeichern();
//            }
//        });
//        
        MenuItem mi3 = new MenuItem("Medienliste in Datei");
//        mi3.setOnAction(new EventHandler<ActionEvent>(){
//            @Override
//            public void handle(ActionEvent event){
//                co.medienInDatei(primaryStage);
//            }
//        });
        
        MenuItem mi4 = new MenuItem("Beenden");
        mi4.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                Platform.exit();
            }
        });
        
        datei.getItems().addAll(mi1, mi3, mi4);

        Menu medium = new Menu("Patient");

        MenuItem mi5 = new MenuItem("Add Patient");
        mi5.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
            	PatientAddView pav = new PatientAddView(new Patient(), co, primaryStage);
                pav.showView();
            }
        });
        
        MenuItem mi6 = new MenuItem("Add Diagnose");
        mi6.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
            	DiagnoseAddView dav = new DiagnoseAddView(new Diagnose(), co, primaryStage);
                dav.showView();
            }
        });
        
        
        medium.getItems().addAll(mi5, mi6);


        mb.getMenus().addAll(datei, medium);

        BorderPane bp = new BorderPane();

        //lv.setItems(co.getList());
        lv.setItems(co.getList());
        bp.setTop(mb);
        bp.setCenter(lv);

        Scene scene = new Scene(bp, 300.0, 200.0);
        primaryStage.setTitle("Patient administration");
        primaryStage.setScene(scene);
        primaryStage.show();

		
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
