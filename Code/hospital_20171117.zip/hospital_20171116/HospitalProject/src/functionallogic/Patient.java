package functionallogic;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

import com.google.gson.Gson;

public class Patient {
	
	private String familyName;
	private String givenName;
	private String patientID;
	private String streetName;
	private String dwellingNumber;
	private String fhirid;

	public String[] getGivenNameArray() {
		return givenNameArray;
	}

	public void setGivenNameArray(String[] givenNameArray) {
		this.givenNameArray = givenNameArray;
	}

	private String[] givenNameArray;

	public Patient() {

	}


	public String getFhirid() {
		return fhirid;
	}

	public void setFhirid(String fhirid) {
		this.fhirid = fhirid;
	}

	public String getPatientID() {
		return patientID;
	}



	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}



	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	

	public String getStreetName() {
		return streetName;
	}



	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}



	public String getDwellingNumber() {
		return dwellingNumber;
	}



	public void setDwellingNumber(String dwellingNumber) {
		this.dwellingNumber = dwellingNumber;
	}



	@Override
	public String toString() {
		return  familyName + " " + givenName + " " + patientID;
	}
	public String toString2() {
		String ergebnis = familyName + " ";
		for(int i = 0; i<this.getGivenNameArray().length; i++){
			ergebnis += this.getGivenNameArray()[i] + " ";
		}
		ergebnis += fhirid;
		return ergebnis;
	}

	//für FHIR benötigt:
	public static Patient getPatient(int id){
		// User jsonUser = null;

		try{
			//Usernamen erhalten
			String url = "http://jsonplaceholder.typicode.com/users/" + id;
			InputStreamReader reader = new InputStreamReader(new URL(url).openStream());
			String getResult = getString(reader);
			Patient patient = new Gson().fromJson(getResult, Patient.class);

			return patient;

		}catch (Exception ex){
			ex.printStackTrace();
		}

		return null;
	}

	public static String getString(InputStreamReader reader) throws IOException {

		StringBuilder textBuilder = new StringBuilder();
		int c = 0;
		while((c = reader.read()) != -1) {
			textBuilder.append((char) c);
		}
		return textBuilder.toString();

	}
	
	

}
