package gui;


import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import functionallogic.Patient;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;


public class FhirPatientSearchView extends Stage {

    private ObservableList<String> list = FXCollections.observableArrayList();
    private ObservableList<Patient> patlist = FXCollections.observableArrayList();
    private Controller co;

    public FhirPatientSearchView(Controller co, Stage primaryStage) {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.co = co;
    }

    private void loadList(String url) {

        list.clear();
        patlist.clear();

        for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

            JsonElement root = new JsonParser().parse(url);
            JsonElement entry = root.getAsJsonObject().get("entry");
            JsonElement current_entry = entry.getAsJsonArray().get(i);
            JsonElement resource = current_entry.getAsJsonObject().get("resource");
            JsonElement name = resource.getAsJsonObject().get("name");
            JsonArray nameList = name.getAsJsonArray();
            JsonElement nameListEntry = nameList.get(0);
            String famname = nameListEntry.getAsJsonObject().get("family").getAsString();

            String[] nameListArray = new String[nameList.size()];
            for(int a = 0; a < nameListArray.length; a++){
                nameListEntry = nameList.get(a);
                nameListArray[a] = nameListEntry.getAsJsonObject().get("given").getAsString();
            }

            JsonElement id = resource.getAsJsonObject().get("id");
            String fhirid = id.getAsString();

            Patient pat = new Patient();
            pat.setFamilyName(famname);
            pat.setGivenNameArray(nameListArray);
            pat.setFhirid(fhirid);

            list.add(pat.toString2());
            patlist.add(pat);
        }
    }

    private void loadList2(String url, String text1, String text2) {

        loadList(url);
        LinkedList<Integer> merker = new LinkedList<Integer>();

        if(text1.equals("") | text2.equals("")){
            if(text1.equals("")){
                for(int i = 0; i<patlist.size(); i++) {
                    if (patlist.get(i).getFamilyName().startsWith(text2)) {
                    }else{
                        merker.add(i);
                    }
                }

                for(int a = merker.size() -1; a >= 0; a--){
                    patlist.remove((int) merker.get(a));
                    merker.remove(a);
                }

                list.clear();
                for(int i = 0; i < patlist.size(); i++){
                    list.add(patlist.get(i).toString2());
                }
            }else{
                for(int i = 0; i<patlist.size(); i++) {
                    if (patlist.get(i).getGivenNameArray()[0].startsWith(text1)) {
                    }else{
                        merker.add(i);
                    }
                }

                for(int a = merker.size() -1; a >= 0; a--){
                    patlist.remove((int) merker.get(a));
                    merker.remove(a);
                }

                list.clear();
                for(int i = 0; i < patlist.size(); i++){
                    list.add(patlist.get(i).toString2());
                }
            }
        }else{
            for(int i = 0; i<patlist.size(); i++) {
                if (patlist.get(i).getFamilyName().startsWith(text2) && (patlist.get(i).getGivenNameArray()[0].startsWith(text1))) {
                }else{
                    merker.add(i);
                }
            }

            for(int a = merker.size() -1; a >= 0; a--){
                patlist.remove((int) merker.get(a));
                merker.remove(a);
            }

            list.clear();
            for(int i = 0; i < patlist.size(); i++){
                list.add(patlist.get(i).toString2());
            }
        }
    }


    public void showView() {

        ListView lv = new ListView();

        Label text = new Label("Geben Sie die Patientendaten ein: ");
        Label vorname = new Label("Vorname: ");
        Label nachname = new Label("Nachname: ");


        TextField t1 = new TextField("");
        TextField t2 = new TextField("");

        Button suchen = new Button("Suchen");
        Button abbr = new Button("Abbrechen");
        Button speichern = new Button("Speichern");

        suchen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(t1.getText().equals("") && (t2.getText().equals(""))) {
                            // URl als Json auslesen
                            String json = null;
                            try {
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Patient?&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            loadList(json);

                    }else {
                            // URl als Json auslesen - givenname
                            String json = null;
                            try {
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Patient?&_format=json");
                             } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            loadList2(json, t1.getText(), t2.getText());
                        }
                }catch(NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        speichern.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Patient patient = patlist.get(lv.getSelectionModel().getSelectedIndex());
                    patient.setPatientID(co.getNewPatientID());
                    patient.setGivenName(patient.getGivenNameArray()[0]);
                    patient.setFamilyName(patient.getFamilyName());
                    co.patientAdd(patient);
                    close();
                } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        lv.setItems(list);

        HBox hb = new HBox();
        hb.getChildren().addAll(suchen, speichern, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addRow(0, text);
        gp.addRow(1,vorname, t1);
        gp.addRow(2,nachname, t2);
        gp.add(lv, 0, 3,3,3);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t1, Priority.ALWAYS);
        GridPane.setHalignment(text, HPos.RIGHT);
        GridPane.setHalignment(vorname, HPos.RIGHT);
        GridPane.setHalignment(nachname, HPos.RIGHT);

        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);


        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Patienten des FHIR Servers");

        this.show();
    }

    private static String readUrl(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);

            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }

}
