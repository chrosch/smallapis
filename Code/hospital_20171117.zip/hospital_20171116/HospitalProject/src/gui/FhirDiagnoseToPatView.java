package gui;

import functionallogic.Diagnose;
import functionallogic.Patient;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class FhirDiagnoseToPatView extends Stage {

    private ObservableList<String> list = FXCollections.observableArrayList();
    private ObservableList<Diagnose> diaglist;
    private Patient pat;
    private Controller co;

    public FhirDiagnoseToPatView(Controller co, ObservableList<Diagnose> diagList, Patient pat, Stage primaryStage) {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.pat = pat;
        this.diaglist = diagList;
        this.co = co;
    }


    public void showView() {

        ListView lv = new ListView();

        Label text = new Label("Diagnose zu Patient " + pat.getGivenName() + " " + pat.getFamilyName() + " " + pat.getFhirid());


        Button abbr = new Button("Abbrechen");
        Button speichern = new Button ("Speichern");
        Button alleSpeichern = new Button("Alle Speichern");

        alleSpeichern.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(pat.getPatientID() == null) {
                        try {
                            Patient patient = pat;
                            patient.setPatientID(co.getNewPatientID());
                            patient.setGivenName(patient.getGivenNameArray()[0]);
                            patient.setFamilyName(patient.getFamilyName());
                            co.patientAdd(patient);
                            close();
                        } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                        }
                    }

                    for(int i = 0; i < diaglist.size(); i++) {
                        Diagnose diagnose = diaglist.get(i);
                        diagnose.setAdGivenName(pat.getGivenName());
                        diagnose.setAdFamilyName(pat.getFamilyName());
                        diagnose.setAdPrefix(null);

                        co.diagnoseAdd(diagnose);
                    }

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Diagnose eingefügt");
                    alert.setHeaderText(null);
                    alert.setContentText("Die Diagnosen wurden eingefügt.");
                    alert.showAndWait();
                } catch (Exception e) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        speichern.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try{
                    if(pat.getPatientID() == null){
                        try {
                            System.out.println("Click");
                            Patient patient = pat;
                            patient.setPatientID(co.getNewPatientID());
                            patient.setGivenName(patient.getGivenNameArray()[0]);
                            patient.setFamilyName(patient.getFamilyName());
                            co.patientAdd(patient);
                        } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                        }
                    }

                    Diagnose diagnose = diaglist.get(lv.getSelectionModel().getSelectedIndex());
                    diagnose.setAdGivenName(pat.getGivenName());
                    diagnose.setAdFamilyName(pat.getFamilyName());
                    diagnose.setAdPrefix(null);

                    co.diagnoseAdd(diagnose);

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Diagnose eingefügt");
                    alert.setHeaderText(null);
                    alert.setContentText("Die Diagnose " + diagnose.getResult() + " wurde eingefügt.");
                    alert.showAndWait();
                }catch (Exception e) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Diagnose auswählen");
                    alert.setHeaderText(null);
                    alert.setContentText("Bitte wählen Sie eine Diagnose aus.");
                    alert.showAndWait();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        for(int i = 0; i< diaglist.size() -1; i++){
            list.add(diaglist.get(i).toString2());
        }

        lv.setItems(list);

        HBox hb = new HBox();
        hb.getChildren().addAll(speichern, alleSpeichern, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addRow(0, text);
        gp.add(lv, 0, 1,3,3);
        gp.setPadding(new Insets(10.0));
        GridPane.setHalignment(text, HPos.RIGHT);

        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);


        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Diagnosen des FHIR Servers");

        this.show();
    }

}
