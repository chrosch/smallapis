package gui;

import functionallogic.Diagnose;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DiagnoseAddView extends Stage{
	private Diagnose diagnose;
	private Controller co;

	public DiagnoseAddView(Diagnose diagnose, Controller co, Stage primaryStage) {
		this.initOwner(primaryStage);
		this.initModality(Modality.WINDOW_MODAL);
		this.diagnose = diagnose;
		this.co = co;
	}
	

    public void showView() {
        Label l1 = new Label("Patient ID:");
        Label l2 = new Label("Visitnumber:");
        Label l3 = new Label("Result:");
        Label l4 = new Label("Attending Doctor ID:");
        Label l5 = new Label("Attending Doctor Prefix:");
        Label l6 = new Label("Attending Doctor given Name:");
        Label l7 = new Label("Attending Doctor family Name:");

        TextField t1;
        TextField t2;
        TextField t3;
        TextField t4;
        TextField t5;
        TextField t6;
        TextField t7;

        if (diagnose != null) {
        	diagnose.setVisitNumber(co.getNewPatientID()); //muss �berarbeitet werden, Punkt der �bergabe muss besser gestalltet werden 
            t1 = new TextField(diagnose.getPatientID());
            t2 = new TextField(diagnose.getVisitNumber());
            t3 = new TextField(diagnose.getResult());
            t4 = new TextField(diagnose.getAdID());
            t5 = new TextField(diagnose.getAdPrefix());
            t6 = new TextField(diagnose.getAdGivenName());
            t7 = new TextField(diagnose.getAdFamilyName());
            
        } else {
            t1 = new TextField("");
            t2 = new TextField("");
            t3 = new TextField("");
            t4 = new TextField("");
            t5 = new TextField("");
            t6 = new TextField("");
            t7 = new TextField("");
        }

        Button neu = new Button("Add");
        Button abbr = new Button("Cancel");

        neu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                	diagnose.setPatientID(t1.getText());
                	diagnose.setVisitNumber(t2.getText());
                	diagnose.setResult(t3.getText());
                	diagnose.setAdID(t4.getText());
                	diagnose.setAdPrefix(t5.getText());
                	diagnose.setAdGivenName(t6.getText());
                	diagnose.setAdFamilyName(t7.getText());
                    co.diagnoseAdd(diagnose);
                    close();
                } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        HBox hb = new HBox();
        hb.getChildren().addAll(neu, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addColumn(0, l1, l2, l3, l4, l5, l6, l7);
        gp.addColumn(1, t1, t2, t3, t4, t5, t6, t7);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t1, Priority.ALWAYS);
        GridPane.setHalignment(l1, HPos.RIGHT);
        GridPane.setHalignment(l2, HPos.RIGHT);
        GridPane.setHalignment(l3, HPos.RIGHT);
        GridPane.setHalignment(l4, HPos.RIGHT);
        GridPane.setHalignment(l5, HPos.RIGHT);
        GridPane.setHalignment(l6, HPos.RIGHT);
        GridPane.setHalignment(l7, HPos.RIGHT);
        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);

        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Diagnose Add");

        this.show();
    }

}
