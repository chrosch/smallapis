package gui;

import functionallogic.Diagnose;
import functionallogic.Patient;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import static functionallogic.User.us;


public class firstSite extends Application{

	@Override
	public void start(Stage primaryStage) {

	    /*//Verbindungsaufbau für den FHIR Server
        //create the FHIR context
        FhirContext ctx = FhirContext.forDstu3();
       // String serverBase = "fhirtest.uhn.ca/baseDstu3/";
        IGenericClient client = ctx.newRestfulGenericClient("https://fhir.molit.eu/baseDstu3");*/


		Controller co = new Controller();
        ListView lv = new ListView();
            
        MenuBar mb = new MenuBar();
        Menu datei = new Menu("Object");

        MenuItem mi1 = new MenuItem("Load Patient List");
        MenuItem mi2 = new MenuItem("Load Diagnostic of Patient");
        MenuItem mi3 = new MenuItem("Patient Search");
        MenuItem mi4 = new MenuItem("Beenden");


        mi1.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle (ActionEvent event){
                    co.patientListLoad();
            }
        });

        mi2.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                    PatientDiagnosticListView pdlv = new PatientDiagnosticListView(new Patient(), co, primaryStage);
                    pdlv.showView();
            }
        });
//
        mi3.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                    SinglePatientView spv = new SinglePatientView(new Patient(), co, primaryStage);
                    spv.showView();
            }
        });

        mi4.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });


        datei.getItems().addAll(mi1, mi2, mi3, mi4);

        Menu medium = new Menu("Patient");

        MenuItem mi5 = new MenuItem("Add Patient");
        MenuItem mi6 = new MenuItem("Add Diagnose");


        mi5.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                    PatientAddView pav = new PatientAddView(new Patient(), co, primaryStage);
                    pav.showView();
            }
        });

        mi6.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                    DiagnoseAddView dav = new DiagnoseAddView(new Diagnose(), co, primaryStage);
                    dav.showView();
            }
        });



        medium.getItems().addAll(mi5, mi6);

        //Menu login = new Menu("Benutzer");

       /* MenuItem mi7 = new MenuItem("Anmelden");
        mi7.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                UserView uv = new UserView(co,primaryStage);
                uv.showView();
            }
        });

        MenuItem mi8 = new MenuItem("Abmelden");
        mi8.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
                us.setRechte(0);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Abmeldung");
                alert.setHeaderText(null);
                alert.setContentText("Sie wurden erfolgreich abgemeldet");
                alert.showAndWait();
            }
        });*/
        
        //login.getItems().addAll(mi7, mi8);


        Menu server = new Menu("Server");

        MenuItem mi9 = new MenuItem("Suche Patient");
        //MenuItem mi10 = new MenuItem("Suche Diagnose");
        MenuItem mi11 = new MenuItem("Suche Diagnose zu Patient");


        mi9.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FhirPatientSearchView fps = new FhirPatientSearchView(co, primaryStage);
                fps.showView();
            }
        });

        //Funktion Diagnose suchen - rausgenommen, da diagnosen nicht ohne pat gespeichert werden können
        /*mi10.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FhirDiagnoseSearchView fdsv = new FhirDiagnoseSearchView(primaryStage);
                fdsv.showView();
            }
        });*/


        mi11.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                FhirPatientDiagnoseView fpdv = new FhirPatientDiagnoseView(co, primaryStage);
                fpdv.showView();
            }
        });



        server.getItems().addAll(mi9, mi11);

        mb.getMenus().addAll(datei, medium, server);

        BorderPane bp = new BorderPane();

        //lv.setItems(co.getList());
        lv.setItems(co.getList());
        bp.setTop(mb);
        bp.setCenter(lv);

        Scene scene = new Scene(bp, 300.0, 200.0);
        primaryStage.setTitle("Patient administration");
        primaryStage.setScene(scene);
        primaryStage.show();

		
	}
	
	public static void main(String[] args) {
	    launch(args);
	}

}
