package gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import functionallogic.Diagnose;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;


public class FhirDiagnoseSearchView extends Stage {

    private ObservableList<String> list = FXCollections.observableArrayList();
    private ObservableList<Diagnose> diaglist = FXCollections.observableArrayList();

    public FhirDiagnoseSearchView(Stage primaryStage) {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);

    }

    private void loadList(String url) {

        list.clear();
        diaglist.clear();

        for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

            JsonElement root = new JsonParser().parse(url);
            JsonElement entry = root.getAsJsonObject().get("entry");
            JsonElement current_entry = entry.getAsJsonArray().get(i);
            JsonElement resource = current_entry.getAsJsonObject().get("resource");
            JsonElement id = resource.getAsJsonObject().get("id");
            String idstring = id.getAsString();

            JsonElement code = resource.getAsJsonObject().get("code");
            String text = code.getAsJsonObject().get("text").getAsString();

            JsonElement subject = resource.getAsJsonObject().get("subject");
            JsonElement reference = subject.getAsJsonObject().get("reference");
            String withPatient = reference.getAsString();
            String Patientid = withPatient.substring(8);

            Diagnose diag = new Diagnose();
            diag.setAdID(idstring);
            diag.setPatientID(Patientid);
            diag.setResult(text);

            list.add(diag.toString2());
            diaglist.add(diag);
        }
    }

    private void loadList2(String url, String text) {

        loadList(url);
        LinkedList<Integer> merker = new LinkedList<Integer>();

        for(int i = 0; i<diaglist.size(); i++) {
            if (diaglist.get(i).getResult().startsWith(text)) {
            }else{
                merker.add(i);
            }
        }

        for(int a = merker.size() -1; a >= 0; a--){
                diaglist.remove((int) merker.get(a));
                merker.remove(a);
        }

        list.clear();
        for(int i = 0; i < diaglist.size(); i++){
            list.add(diaglist.get(i).toString2());
        }
    }


    public void showView() {

        ListView lv = new ListView();

        Label text = new Label("Geben Sie die Diagnose ein: ");

        TextField t1 = new TextField("");


        Button suchen = new Button("Suchen");
        Button abbr = new Button("Abbrechen");

        suchen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(t1.getText().equals("")) {
                            // URl als Json auslesen
                            String json = null;
                            try {
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Condition?&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Diagnose Liste ausgeben
                            loadList(json);

                    }else{
                            // URl als Json
                            String json = null;
                            try {
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Condition?&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                        //Diagnose Liste ausgeben
                        loadList2(json, t1.getText().trim());
                    }
                }catch(NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        lv.setItems(list);

        HBox hb = new HBox();
        hb.getChildren().addAll(suchen, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addRow(0, text, t1);
        gp.add(lv, 0, 1,3,3);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t1, Priority.ALWAYS);
        GridPane.setHalignment(text, HPos.RIGHT);

        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);


        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Diagnosen des FHIR Servers");

        this.show();
    }

    private static String readUrl(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);

            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }

}