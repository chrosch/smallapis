package gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import functionallogic.Diagnose;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import functionallogic.Patient;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;


public class FhirPatientDiagnoseView extends Stage {

    private ObservableList<String> list = FXCollections.observableArrayList();
    private ObservableList<Patient> patlist = FXCollections.observableArrayList();
    private ObservableList<Diagnose> diaglist = FXCollections.observableArrayList();
    private Stage primary;
    private Controller co;

    public FhirPatientDiagnoseView(Controller co, Stage primaryStage) {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.primary = primaryStage;
        this.co = co;
    }

    private void loadPatList(String url) {

        list.clear();

        for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

            JsonElement root = new JsonParser().parse(url);
            JsonElement entry = root.getAsJsonObject().get("entry");
            JsonElement current_entry = entry.getAsJsonArray().get(i);
            JsonElement resource = current_entry.getAsJsonObject().get("resource");
            JsonElement name = resource.getAsJsonObject().get("name");
            JsonArray nameList = name.getAsJsonArray();
            JsonElement nameListEntry = nameList.get(0);
            String famname = nameListEntry.getAsJsonObject().get("family").getAsString();

            String[] nameListArray = new String[nameList.size()];
            for(int a = 0; a < nameListArray.length; a++){
                nameListEntry = nameList.get(a);
                nameListArray[a] = nameListEntry.getAsJsonObject().get("given").getAsString();
            }

            JsonElement id = resource.getAsJsonObject().get("id");
            String fhirid = id.getAsString();

            Patient pat = new Patient();
            pat.setFamilyName(famname);
            pat.setGivenNameArray(nameListArray);
            pat.setFhirid(fhirid);

            list.add(pat.toString2());
            patlist.add(pat);
        }
    }

    private void loadDiagList(String url) {

        list.clear();
        diaglist.clear();

        try{
            for (int i = 0; i < new JsonParser().parse(url).getAsJsonObject().get("entry").getAsJsonArray().size(); i++) {

                JsonElement root = new JsonParser().parse(url);
                JsonElement entry = root.getAsJsonObject().get("entry");
                JsonElement current_entry = entry.getAsJsonArray().get(i);
                JsonElement resource = current_entry.getAsJsonObject().get("resource");
                JsonElement id = resource.getAsJsonObject().get("id");
                String idstring = id.getAsString();

                JsonElement code = resource.getAsJsonObject().get("code");
                String text = code.getAsJsonObject().get("text").getAsString();

                JsonElement subject = resource.getAsJsonObject().get("subject");
                JsonElement reference = subject.getAsJsonObject().get("reference");
                String withPatient = reference.getAsString();
                String Patientid = withPatient.substring(8);

                JsonElement meta = resource.getAsJsonObject().get("meta");
                JsonElement versionID = meta.getAsJsonObject().get("versionId");
                String visitNumber = versionID.getAsString();

                Diagnose diag = new Diagnose();
                diag.setVisitNumber(visitNumber);
                diag.setAdID(idstring);
                diag.setPatientID(Patientid);
                diag.setResult(text);

                diaglist.add(diag);
            }
        }catch (Exception e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Keine Diagnosen gefunden");
            alert.setHeaderText(null);
            alert.setContentText("Es wurden keine Diagnosen gefunden");
            alert.showAndWait();

            close();
        }
    }


    public void showView() {

        ListView lv = new ListView();

        Label text = new Label("Geben Sie die Patientendaten ein: ");
        Label vorname = new Label("Vorname: ");
        Label nachname = new Label("Nachname: ");


        TextField t1 = new TextField("");
        TextField t2 = new TextField("");

        Button suchen = new Button("Suchen");
        Button abbr = new Button("Abbrechen");
        Button sucheDiag = new Button("Suche Diagnose");

        sucheDiag.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //Patient von der Liste bekommen
                try {
                    Patient pat = patlist.get(lv.getSelectionModel().getSelectedIndex());
                    patlist.clear();

                    String json = null;
                    try {
                        json = readUrl("https://fhir.molit.eu/baseDstu3/Condition?patient=" + pat.getFhirid() + "&_format=json)");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //Json in Patienten Objekt verwandeln
                    loadDiagList(json);

                    //Diagnosen zu Pat anzeigen
                    FhirDiagnoseToPatView fdtpv = new FhirDiagnoseToPatView(co, diaglist, pat, primary);
                    fdtpv.showView();
                }catch(Exception e){
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Diagnose auswählen");
                    alert.setHeaderText(null);
                    alert.setContentText("Bitte wählen Sie eine Diagnose aus.");
                    alert.showAndWait();
                }
            }
        });

        suchen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(t1.getText().equals("")) {
                        if (t2.getText().equals("")) {
                            // URl als Json auslesen
                            String json = null;
                            try {
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Patient?&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            loadPatList(json);

                        }else{
                            // URl als Json auslesen - familyname
                            String json = null;
                            try {
                                System.out.println("https://fhir.molit.eu/baseDstu3/Patient?_family=" + t2.getText() + "&_format=json");
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Patient?_family=" + t2.getText() + "&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            loadPatList(json);
                        }
                    }else{
                        if(t2.getText().equals("")){
                            // URl als Json auslesen - givenname
                            String json = null;
                            try {
                                System.out.println("https://fhir.molit.eu/baseDstu3/Patient?_given=" + t1.getText() + "&_format=json");
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Patient?_given=" + t1.getText() + "&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            loadPatList(json);
                        }else{
                            // URl als Json auslesen - givenname + familyname
                            String json = null;
                            try {
                                System.out.println("https://fhir.molit.eu/baseDstu3/Patient?family=" + t2.getText() + "&given=" + t1.getText() + "&_format=json");
                                json = readUrl("https://fhir.molit.eu/baseDstu3/Patient?family=" + t2.getText() + "&given=" + t1.getText() +  "&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            loadPatList(json);
                        }
                    }
                }catch(NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        lv.setItems(list);

        HBox hb = new HBox();
        hb.getChildren().addAll(sucheDiag, suchen, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addRow(0, text);
        gp.addRow(1,vorname, t1);
        gp.addRow(2,nachname, t2);
        gp.add(lv, 0, 3,3,3);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t1, Priority.ALWAYS);
        GridPane.setHalignment(text, HPos.RIGHT);
        GridPane.setHalignment(vorname, HPos.RIGHT);
        GridPane.setHalignment(nachname, HPos.RIGHT);

        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);


        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Patienten des FHIR Servers");

        this.show();
    }

    private static String readUrl(String urlString) throws Exception {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuffer buffer = new StringBuffer();
            int read;
            char[] chars = new char[1024];
            while ((read = reader.read(chars)) != -1)
                buffer.append(chars, 0, read);

            return buffer.toString();
        } finally {
            if (reader != null)
                reader.close();
        }
    }

}
