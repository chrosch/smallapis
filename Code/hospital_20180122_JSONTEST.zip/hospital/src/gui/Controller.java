package gui;

import java.util.Iterator;

import functionallogic.Comparator;
import functionallogic.Diagnose;
import functionallogic.FhirPostMethod;
import functionallogic.Patient;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Controller {
	private Comparator com;
	private FhirPostMethod fpm;
    private ObservableList<String> ol = FXCollections.observableArrayList();
    
    public Controller(){
        com = new Comparator();
        fpm = new FhirPostMethod();
    }
    
    public void patientListLoad(){
        com.patientListRead();
        ol.clear();
        Iterator<?> it = com.patientIterator();
        while(it.hasNext()){
            ol.add(it.next().toString());
        }
        /*
        for(Medium m: mv.iterator().hasNext()){
            ol.add(m.toString());
        }
         */
    }
    
    public void patientDiagnosticListLoad(String patientID) {
    	ol.clear();
    	com.diagnoseListRead(patientID);
    	Iterator<?> it = com.diagnoseIterator();
        while(it.hasNext()){
            ol.add(it.next().toString());
        }
    }
    
    public void patientLoad(String patientID){
    	ol.clear();
    	ol.add(com.patientRead(patientID).toString());
    }
    
    public String getNewPatientID() {
    	return com.generatePatientID();
    }
    
    public void patientAdd(Patient patient) {
    	com.patientWrite(patient);
    	com.patientAddToList(patient);
    	ol.add(patient.toString());
    }
    
    public void fhirPatientAdd(Patient patient) {
    	fpm.speichern(fpm.patientBuilder(patient));
    }
    
    public void diagnoseAdd(Diagnose diagnose) {
    	com.diagnoseWrite(diagnose);
    	com.diagnoseAddToList(diagnose);
    	ol.add(diagnose.toString());
    }
    
    
    
//    public void medienInDatei(Stage ob){
//        String dateiname = InputView.create(ob, "Eingabe", "Dateiname", null).showView();
//        mv.medienInDateiSchreiben(dateiname);
//    }
    
    public ObservableList<String> getList(){
        return ol;
    }

}
