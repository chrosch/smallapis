package gui;

public class FhirCreatePatientView {

}
