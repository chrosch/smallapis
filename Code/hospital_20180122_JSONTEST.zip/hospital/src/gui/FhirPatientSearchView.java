package gui;

import functionallogic.FhirMethods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import functionallogic.Patient;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class FhirPatientSearchView extends Stage {

    private ObservableList<String> list = FXCollections.observableArrayList();
    private ObservableList<Patient> patlist = FXCollections.observableArrayList();
    private Controller co;
    private FhirMethods meth;

    public FhirPatientSearchView(Controller co, Stage primaryStage) {
        this.initOwner(primaryStage);
        this.initModality(Modality.WINDOW_MODAL);
        this.co = co;
        this.meth = new FhirMethods();
    }

    public void showView() {

        ListView lv = new ListView();

        Label text = new Label("Geben Sie die Patientendaten ein: ");
        Label vorname = new Label("Vorname: ");
        Label nachname = new Label("Nachname: ");

        TextField t1 = new TextField("");
        TextField t2 = new TextField("");

        Button suchen = new Button("Suchen");
        Button abbr = new Button("Abbrechen");
        Button speichern = new Button("Speichern");

        suchen.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    if(t1.getText().equals("") && (t2.getText().equals(""))) {
                            // URl als Json auslesen
                            String json = null;
                            try {
                                json = meth.readUrl("https://fhir.molit.eu/baseDstu3/Patient?&_format=json");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            meth.loadList(json, patlist);
                            meth.loadStringList(patlist, list);

                    }else {
                            // URl als Json auslesen - givenname
                            String json = null;
                            try {
                                json = meth.readUrl("https://fhir.molit.eu/baseDstu3/Patient?&_format=json");
                             } catch (Exception e) {
                                e.printStackTrace();
                            }

                            //Json in Patienten Objekt verwandeln
                            patlist = meth.loadList2(json, t1.getText(), t2.getText(),patlist,list);
                            list = meth.loadStringList(patlist, list);
                        }
                }catch(NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        speichern.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Patient patient = patlist.get(lv.getSelectionModel().getSelectedIndex());
                    meth.createPatient(patient, co);
                } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        lv.setItems(list);

        HBox hb = new HBox();
        hb.getChildren().addAll(suchen, speichern, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addRow(0, text);
        gp.addRow(1,vorname, t1);
        gp.addRow(2,nachname, t2);
        gp.add(lv, 0, 3,3,3);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t1, Priority.ALWAYS);
        GridPane.setHalignment(text, HPos.RIGHT);
        GridPane.setHalignment(vorname, HPos.RIGHT);
        GridPane.setHalignment(nachname, HPos.RIGHT);

        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);


        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Patienten des FHIR Servers");

        this.show();
    }

}
