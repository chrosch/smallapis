package gui;

import functionallogic.Patient;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class FhirPatientAddView extends Stage {
	private Patient patient;
	private Controller co;

	public FhirPatientAddView(Patient patient, Controller co, Stage primaryStage) {
		this.initOwner(primaryStage);
		this.initModality(Modality.WINDOW_MODAL);
		this.patient = patient;
		this.co = co;
	}
	

    public void showView() {
        //Label l1 = new Label("Patient ID:");
        Label l2 = new Label("Given Name:");
        Label l3 = new Label("Family Name:");
        Label l4 = new Label("Street Name:");
        Label l5 = new Label("Dwellingnumber:");

        //TextField t1;
        TextField t2;
        TextField t3;
        TextField t4;
        TextField t5;

        if (patient != null) {
        	//patient.setPatientID(co.getNewPatientID()); //muss �berarbeitet werden, Punkt der �bergabe muss besser gestalltet werden 
            //t1 = new TextField(patient.getPatientID());
            t2 = new TextField(patient.getGivenName());
            t3 = new TextField(patient.getFamilyName());
            t4 = new TextField("");
            t5 = new TextField("");
            
        } else {
            //t1 = new TextField("");
            t2 = new TextField("");
            t3 = new TextField("");
            t4 = new TextField("");
            t5 = new TextField("");
        }

        Button neu = new Button("Add");
        Button abbr = new Button("Cancel");

        neu.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                	//patient.setPatientID(t1.getText());
                	patient.setGivenName(t2.getText());
                	patient.setFamilyName(t3.getText());
                    co.fhirPatientAdd(patient);
                    close();
                } catch (NumberFormatException ex) {
//                    MessageView.create(AudioErfassungView.this, "Fehlermeldung", "Bitte nur Zahlen eingeben!").showView();
                }
            }
        });

        abbr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                close();
            }
        });

        HBox hb = new HBox();
        hb.getChildren().addAll(neu, abbr);
        hb.setPadding(new Insets(10.0));
        hb.setSpacing(10.0);
        hb.setAlignment(Pos.CENTER);

        GridPane gp = new GridPane();
        gp.addColumn(0, l2, l3, l4, l5);
        gp.addColumn(1, t2, t3, t4, t5);
        gp.setPadding(new Insets(10.0));
        GridPane.setHgrow(t2, Priority.ALWAYS);
//        GridPane.setHalignment(l1, HPos.RIGHT);
        GridPane.setHalignment(l2, HPos.RIGHT);
        GridPane.setHalignment(l3, HPos.RIGHT);
        GridPane.setHalignment(l4, HPos.RIGHT);
        GridPane.setHalignment(l5, HPos.RIGHT);
        gp.setVgap(10.0);
        gp.setHgap(10.0);
        gp.setAlignment(Pos.CENTER);

        BorderPane bp = new BorderPane();
        bp.setCenter(gp);
        bp.setBottom(hb);

        Scene scene = new Scene(bp);
        this.setScene(scene);
        this.setTitle("Fhir Patient Add");

        this.show();
    }


}
