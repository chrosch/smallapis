package functionallogic;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;

public class FhirPostMethod {
	
	
	public FhirPostMethod() {
		
	}
	
	public JsonObject patientBuilder(Patient patient) {
		JsonObjectBuilder builder = Json.createObjectBuilder();
		builder.add("Vorname", patient.getGivenName());
		builder.add("Nachname", patient.getFamilyName());
		
		
		return builder.build();
	}
	
	public void speichern(JsonObject jo){
		try(FileOutputStream fos = new FileOutputStream("C:\\Users\\anton\\Desktop\\Telematik\\jo.json");
				ObjectOutputStream oos = new ObjectOutputStream(fos)){
			oos.writeObject(jo);
			
		} catch(IOException ex){
			ex.printStackTrace();
		}
	}

}
